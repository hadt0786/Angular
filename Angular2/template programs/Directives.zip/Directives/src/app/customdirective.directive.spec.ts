import { CustomdirectiveDirective } from './customdirective.directive';

describe('CustomdirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomdirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
